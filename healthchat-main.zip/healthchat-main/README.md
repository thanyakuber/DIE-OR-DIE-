# HealthChat
virtual assistance for sick people
